package emitterdriver

import "github.com/ethereum/go-ethereum/common"

// ContractAddress is the EmitterDriver contract address
var ContractAddress = common.HexToAddress("0xee00d10000000000000000000000000000000000")
