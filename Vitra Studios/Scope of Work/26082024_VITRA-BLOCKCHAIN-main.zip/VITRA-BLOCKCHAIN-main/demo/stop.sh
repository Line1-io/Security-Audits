#!/usr/bin/env bash

killall demo_opera
