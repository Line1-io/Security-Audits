#!/usr/bin/env bash
cd $(dirname $0)


rm -fr opera*.datadir
rm *.log
rm ../build/demo_opera
